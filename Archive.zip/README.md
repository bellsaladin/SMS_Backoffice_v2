# keystone-test-project

A KeystoneJS Project with various configurations for development and testing purposes

**Note: This project requires Node.js v4.x or newer**
