var keystone = require('keystone');
var transform = require('model-transform');
var Types = keystone.Field.Types;

var CustomerActivity = new keystone.List('CustomerActivity',
                                        {'label' : 'Activité',
                                         'noedit' : true,
                                         'nocreate' : true,
                                         'nodelete' : true});

CustomerActivity.add({
  customer: { type: Types.Relationship, ref: 'Customer', label : 'Client', index: true },
	operationDate: { type: Date, label: 'Date opération'},
  numberOfSentSMS: { type: Date, label: 'Nbr SMS Envoyés'}
});

transform.toJSON(CustomerActivity);
CustomerActivity.defaultColumns = 'customer, operationDate, numberOfSentSMS';
CustomerActivity.register();
