exports.create = {
	PostCategory: [
		{ name: 'News' },
		{ name: 'Ideas' },
		{ name: 'Node.js' },
		{ name: 'React.js' },
		{ name: 'Other' },
	],
};
